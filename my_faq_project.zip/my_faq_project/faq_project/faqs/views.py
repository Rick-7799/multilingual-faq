from rest_framework import viewsets
from .models import FAQ
from .serializers import FAQSerializer

class FAQViewSet(viewsets.ReadOnlyModelViewSet):
    
    serializer_class = FAQSerializer
    queryset = FAQ.objects.all().order_by('-created_at')
