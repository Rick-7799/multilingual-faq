from django.db import models
from ckeditor.fields import RichTextField

class FAQ(models.Model):
    question = models.TextField(help_text="The original question in English.")
    answer = RichTextField(help_text="Formatted answer (supports bold, italics, links, etc.).")
    
    question_hi = models.TextField(blank=True, verbose_name="Hindi Question")
    question_bn = models.TextField(blank=True, verbose_name="Bengali Question")

    def get_translated_question(self, lang_code='en'):
       
        return getattr(self, f'question_{lang_code}', None) or self.question

    def __str__(self):
        return f"FAQ #{self.id}: {self.question[:50]}..."

    class Meta:
        verbose_name = "Frequently Asked Question"
        verbose_name_plural = "FAQs"
