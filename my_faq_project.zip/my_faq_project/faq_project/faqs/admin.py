from django.contrib import admin
from .models import FAQ
from ckeditor.widgets import CKEditorWidget

@admin.register(FAQ)
class FAQAdmin(admin.ModelAdmin):
    list_display = ('question', 'created_at')
    search_fields = ('question', 'answer')
    formfield_overrides = {
        models.TextField: {'widget': CKEditorWidget(config_name='default')},
    }

    fieldsets = (
        ('English Content', {
            'fields': ('question', 'answer')
        }),
        ('Translations', {
            'fields': ('question_hi', 'question_bn'),
            'classes': ('collapse',) 
        }),
    )
